using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;

namespace Jupiter.UI;

/// <summary>
/// The shared Settings > Appearance > Accent color control. Set <see cref="Service"/> once.
/// </summary>
public sealed partial class AccentColorSetting : UserControl
{
    private AccentService? _service;
    private bool _updating;

    public AccentColorSetting()
    {
        InitializeComponent();
        Unloaded += (_, _) =>
        {
            if (_service is not null)
            {
                _service.Changed -= Sync;
            }
        };
    }

    public AccentService? Service
    {
        get => _service;
        set
        {
            if (_service is not null)
            {
                _service.Changed -= Sync;
            }
            _service = value;
            if (_service is not null)
            {
                _service.Changed += Sync;
            }
            Sync();
        }
    }

    private void Sync()
    {
        if (_service is null)
        {
            IsEnabled = false;
            return;
        }
        IsEnabled = true;
        _updating = true;
        Choice.SelectedIndex = _service.UseCustomAccent ? 1 : 0;
        _updating = false;
        Swatch.Background = new SolidColorBrush(_service.Current);
        ResetButton.IsEnabled = _service.UseCustomAccent;
    }

    private void OnChoiceChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_updating || _service is null)
        {
            return;
        }
        if (Choice.SelectedIndex == 0)
        {
            _service.UseWindows();
        }
        else
        {
            _service.UseCustom(_service.CustomColor);
        }
    }

    private void OnPickerOpening(object? sender, object e)
    {
        if (_service is not null)
        {
            Picker.Color = _service.Current;
        }
    }

    private void OnApply(object sender, RoutedEventArgs e)
    {
        _service?.UseCustom(Picker.Color);
        PickerFlyout.Hide();
    }

    private void OnReset(object sender, RoutedEventArgs e) => _service?.UseWindows();
}
