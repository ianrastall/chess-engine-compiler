using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Media;
using Windows.UI;
using Windows.UI.ViewManagement;

namespace Jupiter.UI;

/// <summary>
/// Applies the Jupiter accent convention (standard section 3.3): the Windows accent by default,
/// following system changes, or a per-app custom color. Create one per app on the UI thread,
/// after the application resources are loaded, and attach every window's root element.
/// </summary>
public sealed class AccentService
{
    // Standard 3.2: the accent mixed into each theme's window color for selection and selection hover.
    private static readonly (string Theme, double Selected, double Hover)[] SelectionMixes =
    [
        ("Default", 0.24, 0.30),
        ("Light", 0.16, 0.22),
    ];

    private static readonly string[] SystemKeys =
    [
        "SystemAccentColor",
        "SystemAccentColorLight1", "SystemAccentColorLight2", "SystemAccentColorLight3",
        "SystemAccentColorDark1", "SystemAccentColorDark2", "SystemAccentColorDark3",
    ];

    private readonly UISettings _ui = new();
    private readonly IAccentPreferences _preferences;
    private readonly DispatcherQueue _dispatcher;
    private readonly List<WeakReference<FrameworkElement>> _roots = [];

    public AccentService(IAccentPreferences preferences)
    {
        _preferences = preferences;
        _dispatcher = DispatcherQueue.GetForCurrentThread()
            ?? throw new InvalidOperationException("Create AccentService on the UI thread.");
        _ui.ColorValuesChanged += (_, _) => _dispatcher.TryEnqueue(() =>
        {
            if (!_preferences.UseCustomAccent)
            {
                Apply();
            }
        });
        Apply();
    }

    public event Action? Changed;

    public bool UseCustomAccent => _preferences.UseCustomAccent;

    public Color WindowsAccent => _ui.GetColorValue(UIColorType.Accent);

    /// <summary>The stored custom color, or the Windows accent when none has been chosen.</summary>
    public Color CustomColor => TryParse(_preferences.CustomAccent) ?? WindowsAccent;

    public Color Current => UseCustomAccent ? CustomColor : WindowsAccent;

    /// <summary>Registers a window root so existing elements re-resolve accent resources on change.</summary>
    public void Attach(FrameworkElement root)
    {
        _roots.Add(new WeakReference<FrameworkElement>(root));
        Refresh(root);
    }

    public void UseWindows()
    {
        _preferences.UseCustomAccent = false;
        _preferences.Save();
        Apply();
    }

    public void UseCustom(Color color)
    {
        _preferences.UseCustomAccent = true;
        _preferences.CustomAccent = $"#{color.R:X2}{color.G:X2}{color.B:X2}";
        _preferences.Save();
        Apply();
    }

    private void Apply()
    {
        Color[] palette = UseCustomAccent
            ? Derive(CustomColor)
            :
            [
                _ui.GetColorValue(UIColorType.Accent),
                _ui.GetColorValue(UIColorType.AccentLight1), _ui.GetColorValue(UIColorType.AccentLight2), _ui.GetColorValue(UIColorType.AccentLight3),
                _ui.GetColorValue(UIColorType.AccentDark1), _ui.GetColorValue(UIColorType.AccentDark2), _ui.GetColorValue(UIColorType.AccentDark3),
            ];
        var resources = Application.Current.Resources;
        for (var i = 0; i < SystemKeys.Length; i++)
        {
            resources[SystemKeys[i]] = palette[i];
        }

        // Selection tints are mixed into the window color. Updating the shared brushes in place
        // reaches every control that uses them, including WinUI keys aliased to them.
        foreach (var (key, selected, hover) in SelectionMixes)
        {
            if (FindJupiterTheme(resources, key) is { } theme)
            {
                var window = (Color)theme["JupiterWindowColor"];
                SetBrush(theme, "JupiterSelectedBrush", "JupiterSelectedColor", GeneratedThemeKeys.Selected, Mix(window, palette[0], selected));
                SetBrush(theme, "JupiterSelectedHoverBrush", "JupiterSelectedHoverColor", GeneratedThemeKeys.SelectedHover, Mix(window, palette[0], hover));
            }
        }

        _roots.RemoveAll(r => !r.TryGetTarget(out _));
        foreach (var reference in _roots)
        {
            if (reference.TryGetTarget(out var root))
            {
                Refresh(root);
            }
        }
        Changed?.Invoke();
    }

    // Flipping the requested theme and back makes existing elements re-resolve theme resources,
    // so accent-derived WinUI brushes pick up the new accent; the element keeps its own theme.
    private static void Refresh(FrameworkElement root)
    {
        var theme = root.RequestedTheme;
        root.RequestedTheme = theme == ElementTheme.Light ? ElementTheme.Dark : ElementTheme.Light;
        root.RequestedTheme = theme;
    }

    private static ResourceDictionary? FindJupiterTheme(ResourceDictionary resources, string key)
    {
        foreach (var merged in resources.MergedDictionaries)
        {
            if (merged is JupiterResources jupiter
                && jupiter.ThemeDictionaries.TryGetValue(key, out var theme))
            {
                return theme as ResourceDictionary;
            }
        }
        return null;
    }

    // Updating the brushes in place reaches every control already using them.
    private static void SetBrush(ResourceDictionary theme, string brushKey, string colorKey, string[] controlKeys, Color color)
    {
        theme[colorKey] = color;
        foreach (var key in controlKeys.Prepend(brushKey))
        {
            if (theme.TryGetValue(key, out var value) && value is SolidColorBrush brush)
            {
                brush.Color = color;
            }
        }
    }

    private static Color[] Derive(Color c) =>
    [
        c,
        Mix(c, Colors.White, 0.25), Mix(c, Colors.White, 0.45), Mix(c, Colors.White, 0.65),
        Mix(c, Colors.Black, 0.2), Mix(c, Colors.Black, 0.4), Mix(c, Colors.Black, 0.6),
    ];

    /// <summary>Moves <paramref name="from"/> toward <paramref name="to"/> by <paramref name="amount"/> (0–1).</summary>
    public static Color Mix(Color from, Color to, double amount)
    {
        byte Channel(byte a, byte b) => (byte)Math.Round(a + (b - a) * amount);
        return Color.FromArgb(255, Channel(from.R, to.R), Channel(from.G, to.G), Channel(from.B, to.B));
    }

    public static Color? TryParse(string? text)
    {
        var hex = text?.Trim().TrimStart('#');
        if (hex is not { Length: 6 } || !uint.TryParse(hex, System.Globalization.NumberStyles.HexNumber, null, out var v))
        {
            return null;
        }
        return Color.FromArgb(255, (byte)(v >> 16), (byte)(v >> 8), (byte)v);
    }

    private static class Colors
    {
        public static readonly Color White = Color.FromArgb(255, 255, 255, 255);
        public static readonly Color Black = Color.FromArgb(255, 0, 0, 0);
    }
}
