namespace Jupiter.UI;

/// <summary>
/// The app's stored accent choice. Each app keeps it in its own settings file (standard section 11).
/// </summary>
public interface IAccentPreferences
{
    /// <summary>False (the default) follows the Windows accent color.</summary>
    bool UseCustomAccent { get; set; }

    /// <summary>The custom color as #RRGGBB, or null when none has been chosen.</summary>
    string? CustomAccent { get; set; }

    void Save();
}
