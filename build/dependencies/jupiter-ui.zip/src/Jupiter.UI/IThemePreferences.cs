namespace Jupiter.UI;

/// <summary>
/// The app's stored theme choice (standard section 3.6). Each app keeps it in its own settings file.
/// </summary>
public interface IThemePreferences
{
    /// <summary>"dark", "light" or "system"; null or anything else means dark, the default.</summary>
    string? Theme { get; set; }

    void Save();
}
