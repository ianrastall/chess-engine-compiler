using Microsoft.UI.Xaml;

namespace Jupiter.UI;

/// <summary>
/// The Jupiter style standard's resources. Merge after <c>XamlControlsResources</c> in App.xaml.
/// </summary>
public sealed partial class JupiterResources : ResourceDictionary
{
    public JupiterResources()
    {
        Source = new Uri("ms-appx:///Jupiter.UI/Themes/Jupiter.xaml");
    }
}
