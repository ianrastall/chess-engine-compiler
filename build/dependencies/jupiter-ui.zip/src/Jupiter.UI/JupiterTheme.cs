using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Media;
using Windows.UI.ViewManagement;

namespace Jupiter.UI;

/// <summary>
/// Looks up Jupiter resources from code, for elements created in C# or custom-drawn controls.
/// Theme resources resolve against the contrast theme when one is active (standard section 3.4).
/// </summary>
public static class JupiterTheme
{
    private static readonly AccessibilitySettings Accessibility = new();

    /// <param name="theme">The theme of the element the brush is for; apps with the Theme setting
    /// pass <see cref="ThemeService.Resolved"/>. Dark is the default.</param>
    public static Brush Brush(string key, ElementTheme theme = ElementTheme.Dark) => (Brush)Find(key, theme);

    public static Style Style(string key) => (Style)Find(key);

    public static object Find(string key, ElementTheme theme = ElementTheme.Dark)
    {
        var resources = Application.Current.Resources;
        foreach (var merged in resources.MergedDictionaries)
        {
            if (merged is not JupiterResources jupiter)
            {
                continue;
            }
            var dictionaryKey = Accessibility.HighContrast ? "HighContrast" : theme == ElementTheme.Light ? "Light" : "Default";
            if (jupiter.ThemeDictionaries.TryGetValue(dictionaryKey, out var dictionary)
                && dictionary is ResourceDictionary themed
                && themed.TryGetValue(key, out var value))
            {
                return value;
            }
            if (jupiter.TryGetValue(key, out value))
            {
                return value;
            }
        }
        return resources.TryGetValue(key, out var found)
            ? found
            : throw new KeyNotFoundException($"Jupiter resource '{key}' was not found. Is JupiterResources merged in App.xaml?");
    }
}
