using Microsoft.UI.Dispatching;
using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using Windows.UI.ViewManagement;

namespace Jupiter.UI;

/// <summary>The theme choices of the shared Appearance > Theme setting.</summary>
public enum AppTheme
{
    Dark,
    Light,
    System,
}

/// <summary>
/// Applies the Jupiter theme convention (standard section 3.6): Dark by default, Light, or the
/// Windows app mode, to every attached window (content and title bar) and element. Create one per
/// app on the UI thread, attach each window after InitializeComponent, and attach dialogs before
/// showing them. Apps that do not offer the Theme setting do not use this service.
/// </summary>
public sealed class ThemeService
{
    private readonly UISettings _ui = new();
    private readonly IThemePreferences _preferences;
    private readonly DispatcherQueue _dispatcher;
    private readonly List<WeakReference<Window>> _windows = [];
    private readonly List<WeakReference<FrameworkElement>> _elements = [];

    public ThemeService(IThemePreferences preferences)
    {
        _preferences = preferences;
        _dispatcher = DispatcherQueue.GetForCurrentThread()
            ?? throw new InvalidOperationException("Create ThemeService on the UI thread.");
        _ui.ColorValuesChanged += (_, _) => _dispatcher.TryEnqueue(() =>
        {
            if (Choice == AppTheme.System)
            {
                Apply();
            }
        });
    }

    public event Action? Changed;

    public AppTheme Choice => _preferences.Theme switch
    {
        "light" => AppTheme.Light,
        "system" => AppTheme.System,
        _ => AppTheme.Dark,
    };

    /// <summary>The theme in effect: Dark or Light.</summary>
    public ElementTheme Resolved => Choice switch
    {
        AppTheme.Light => ElementTheme.Light,
        AppTheme.System => WindowsUsesLight ? ElementTheme.Light : ElementTheme.Dark,
        _ => ElementTheme.Dark,
    };

    public bool IsDark => Resolved == ElementTheme.Dark;

    // Windows reports a light app background when apps use light mode.
    private bool WindowsUsesLight => _ui.GetColorValue(UIColorType.Background) is { R: > 128 };

    /// <summary>Themes a window's content and title bar, now and on every change.</summary>
    public void Attach(Window window)
    {
        _windows.Add(new WeakReference<Window>(window));
        ApplyTo(window);
    }

    /// <summary>Themes an element outside a window's content, such as a ContentDialog.</summary>
    public void Attach(FrameworkElement element)
    {
        _elements.Add(new WeakReference<FrameworkElement>(element));
        element.RequestedTheme = Resolved;
    }

    public void Set(AppTheme choice)
    {
        _preferences.Theme = choice switch
        {
            AppTheme.Light => "light",
            AppTheme.System => "system",
            _ => "dark",
        };
        _preferences.Save();
        Apply();
    }

    private void Apply()
    {
        _windows.RemoveAll(w => !w.TryGetTarget(out _));
        _elements.RemoveAll(e => !e.TryGetTarget(out _));
        foreach (var reference in _windows)
        {
            if (reference.TryGetTarget(out var window))
            {
                ApplyTo(window);
            }
        }
        foreach (var reference in _elements)
        {
            if (reference.TryGetTarget(out var element))
            {
                element.RequestedTheme = Resolved;
            }
        }
        Changed?.Invoke();
    }

    private void ApplyTo(Window window)
    {
        if (window.Content is FrameworkElement root)
        {
            root.RequestedTheme = Resolved;
        }
        window.AppWindow.TitleBar.PreferredTheme = IsDark ? TitleBarTheme.Dark : TitleBarTheme.Light;
    }
}
