using Microsoft.UI.Xaml.Controls;

namespace Jupiter.UI;

/// <summary>
/// The shared Settings > Appearance > Theme control. Set <see cref="Service"/> once.
/// </summary>
public sealed partial class ThemeSetting : UserControl
{
    private ThemeService? _service;
    private bool _updating;

    public ThemeSetting()
    {
        InitializeComponent();
        Unloaded += (_, _) =>
        {
            if (_service is not null)
            {
                _service.Changed -= Sync;
            }
        };
    }

    public ThemeService? Service
    {
        get => _service;
        set
        {
            if (_service is not null)
            {
                _service.Changed -= Sync;
            }
            _service = value;
            if (_service is not null)
            {
                _service.Changed += Sync;
            }
            Sync();
        }
    }

    private void Sync()
    {
        IsEnabled = _service is not null;
        if (_service is null)
        {
            return;
        }
        _updating = true;
        Choice.SelectedIndex = (int)_service.Choice;
        _updating = false;
    }

    private void OnChoiceChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!_updating && _service is not null && Choice.SelectedIndex >= 0)
        {
            _service.Set((AppTheme)Choice.SelectedIndex);
        }
    }
}
